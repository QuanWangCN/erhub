library(ggplot2)

p=3+2

p

q=p+2

q
