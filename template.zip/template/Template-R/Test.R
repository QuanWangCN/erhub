grp1 <- rnorm(n = 20,mean = 100,sd = 5)
grp2 <- rnorm(n = 20,mean = 100,sd = 5)

t.test(grp1,grp2)
